"use strict";
angular.module("app", ["ngMaterial", "ngMessages", "angularMoment"]).config(function ($mdThemingProvider, $mdIconProvider) {
    $mdThemingProvider.theme("default").primaryPalette("teal").accentPalette("deep-orange"), $mdIconProvider.icon("alarm", "../images/icons/ic_alarm_white_18px.svg", 18).icon("alarm_add", "../images/icons/ic_add_alarm_white_18px.svg", 18).icon("repeat", "../images/icons/ic_repeat_black_18px.svg", 18).icon("close", "../images/icons/ic_close_white_18px.svg", 18)
}).service("reminderSvr", function ($q) {
    var self = this;
    self.callBackground = function (method) {
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _len > _key; _key++) args[_key - 1] = arguments[_key];
        var d = $q.defer();
        return chrome.runtime.sendMessage({method: method, args: args}, function (response) {
            void 0 !== response.error ? d.reject(response.error) : d.resolve(response.result)
        }), d.promise
    }
}).controller("mainController", function ($scope, $rootScope, $mdDialog, $mdToast, $log, reminderSvr) {
    function fetchData() {
        $log.info("fetching data..."), reminderSvr.callBackground("syncAllReminds", []).then(function (result) {
            $scope.reminds = result.reminds || []
        })
    }

    $scope.i18n = function (key) {
        for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _len2 > _key2; _key2++) args[_key2 - 1] = arguments[_key2];
        return chrome.i18n.getMessage(key, args)
    }, $scope.enableChanged = function (r) {
        reminderSvr.callBackground("saveRemind", r).then(function (nr) {
            r.when = nr.when
        })
    }, $rootScope.editRemind = function ($event) {
        var remind = arguments.length <= 1 || void 0 === arguments[1] ? null : arguments[1];
        $mdDialog.show({
            controller: "dialogController",
            templateUrl: "remind.tmpl.html",
            parent: angular.element(document.body),
            targetEvent: $event,
            clickOutsideToClose: !0,
            locals: {remind: angular.copy(remind)},
            onComplete: function (scope, element) {
                element[0].getElementsByTagName("input")[0].focus()
            }
        }).then(function (response) {
            reminderSvr.callBackground(response.method, response.args).then(function () {
                fetchData()
            }, function (error) {
                console.error(error)
            })
        })
    }, fetchData()
}).controller("dialogController", function ($scope, $mdDialog, reminderSvr, remind) {
    $scope.i18n = function (key) {
        return chrome.i18n.getMessage(key)
    }, $scope.remind = remind || {enable: !0, repeat: !1, message: "", after: 10}, $scope.cancel = function () {
        $mdDialog.cancel()
    }, $scope["delete"] = function () {
        $mdDialog.hide({method: "deleteRemind", args: $scope.remind})
    }, $scope.ok = function () {
        $mdDialog.hide({method: "saveRemind", args: $scope.remind})
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmlwdHMvcG9wdXAuanMiXSwibmFtZXMiOlsiYW5ndWxhciIsIm1vZHVsZSIsImNvbmZpZyIsIiRtZFRoZW1pbmdQcm92aWRlciIsIiRtZEljb25Qcm92aWRlciIsInRoZW1lIiwicHJpbWFyeVBhbGV0dGUiLCJhY2NlbnRQYWxldHRlIiwiaWNvbiIsInNlcnZpY2UiLCIkcSIsInNlbGYiLCJ0aGlzIiwiY2FsbEJhY2tncm91bmQiLCJtZXRob2QiLCJfbGVuIiwiYXJndW1lbnRzIiwibGVuZ3RoIiwiYXJncyIsIkFycmF5IiwiX2tleSIsImQiLCJjaHJvbWUiLCJydW50aW1lIiwic2VuZE1lc3NhZ2UiLCJyZXNwb25zZSIsInVuZGVmaW5lZCIsImVycm9yIiwicmVqZWN0IiwicmVzb2x2ZSIsInJlc3VsdCIsInByb21pc2UiLCJjb250cm9sbGVyIiwiJHNjb3BlIiwiJHJvb3RTY29wZSIsIiRtZERpYWxvZyIsIiRtZFRvYXN0IiwiJGxvZyIsInJlbWluZGVyU3ZyIiwiZmV0Y2hEYXRhIiwiaW5mbyIsInRoZW4iLCJyZW1pbmRzIiwiaTE4biIsImtleSIsIl9sZW4yIiwiX2tleTIiLCJnZXRNZXNzYWdlIiwiZW5hYmxlQ2hhbmdlZCIsInIiLCJuciIsIndoZW4iLCJlZGl0UmVtaW5kIiwiJGV2ZW50IiwicmVtaW5kIiwic2hvdyIsInRlbXBsYXRlVXJsIiwicGFyZW50IiwiZWxlbWVudCIsImRvY3VtZW50IiwiYm9keSIsInRhcmdldEV2ZW50IiwiY2xpY2tPdXRzaWRlVG9DbG9zZSIsImxvY2FscyIsImNvcHkiLCJvbkNvbXBsZXRlIiwic2NvcGUiLCJnZXRFbGVtZW50c0J5VGFnTmFtZSIsImZvY3VzIiwiY29uc29sZSIsImVuYWJsZSIsInJlcGVhdCIsIm1lc3NhZ2UiLCJhZnRlciIsImNhbmNlbCIsImhpZGUiLCJvayJdLCJtYXBwaW5ncyI6IkFBQUEsWUFJQUEsU0FBUUMsT0FBTyxPQUFRLGFBQWMsYUFBYyxrQkFBa0JDLE9BQU8sU0FBVUMsbUJBQW9CQyxpQkFFeEdELG1CQUFtQkUsTUFBTSxXQUFXQyxlQUFlLFFBQVFDLGNBQWMsZUFFekVILGdCQUFnQkksS0FBSyxRQUFTLDBDQUEyQyxJQUFJQSxLQUFLLFlBQWEsOENBQStDLElBQUlBLEtBQUssU0FBVSwyQ0FBNEMsSUFBSUEsS0FBSyxRQUFTLDBDQUEyQyxNQUN6UUMsUUFBUSxjQUFlLFNBQVVDLElBQ2xDLEdBQUlDLE1BQU9DLElBQ1hELE1BQUtFLGVBQWlCLFNBQVVDLFFBQzlCLElBQUssR0FBSUMsTUFBT0MsVUFBVUMsT0FBUUMsS0FBT0MsTUFBTUosS0FBTyxFQUFJQSxLQUFPLEVBQUksR0FBSUssS0FBTyxFQUFVTCxLQUFQSyxLQUFhQSxPQUM5RkYsS0FBS0UsS0FBTyxHQUFLSixVQUFVSSxLQUc3QixJQUFJQyxHQUFJWCxHQUFVLE9BV2xCLE9BVkFZLFFBQU9DLFFBQVFDLGFBQ2JWLE9BQVFBLE9BQ1JJLEtBQU1BLE1BQ0wsU0FBVU8sVUFDWUMsU0FBbkJELFNBQVNFLE1BQ1hOLEVBQUVPLE9BQU9ILFNBQVNFLE9BRWxCTixFQUFFUSxRQUFRSixTQUFTSyxVQUdoQlQsRUFBRVUsV0FJWkMsV0FBVyxpQkFBa0IsU0FBVUMsT0FBUUMsV0FBWUMsVUFBV0MsU0FBVUMsS0FBTUMsYUFTckYsUUFBU0MsYUFDUEYsS0FBS0csS0FBSyxvQkFDVkYsWUFBWXpCLGVBQWUscUJBQXNCNEIsS0FBSyxTQUFVWCxRQUM5REcsT0FBT1MsUUFBVVosT0FBT1ksY0FYNUJULE9BQU9VLEtBQU8sU0FBVUMsS0FDdEIsSUFBSyxHQUFJQyxPQUFRN0IsVUFBVUMsT0FBUUMsS0FBT0MsTUFBTTBCLE1BQVEsRUFBSUEsTUFBUSxFQUFJLEdBQUlDLE1BQVEsRUFBV0QsTUFBUkMsTUFBZUEsUUFDcEc1QixLQUFLNEIsTUFBUSxHQUFLOUIsVUFBVThCLE1BRzlCLE9BQU94QixRQUFPcUIsS0FBS0ksV0FBV0gsSUFBSzFCLE9BVXJDZSxPQUFPZSxjQUFnQixTQUFVQyxHQUMvQlgsWUFBWXpCLGVBQWUsYUFBY29DLEdBQUdSLEtBQUssU0FBVVMsSUFDekRELEVBQUVFLEtBQU9ELEdBQUdDLFFBSWhCakIsV0FBV2tCLFdBQWEsU0FBVUMsUUFDaEMsR0FBSUMsUUFBU3RDLFVBQVVDLFFBQVUsR0FBc0JTLFNBQWpCVixVQUFVLEdBQW1CLEtBQU9BLFVBQVUsRUFFcEZtQixXQUFVb0IsTUFDUnZCLFdBQVksbUJBQ1p3QixZQUFhLG1CQUNiQyxPQUFRekQsUUFBUTBELFFBQVFDLFNBQVNDLE1BQ2pDQyxZQUFhUixPQUNiUyxxQkFBcUIsRUFDckJDLFFBQVVULE9BQVF0RCxRQUFRZ0UsS0FBS1YsU0FDL0JXLFdBQVksU0FBb0JDLE1BQU9SLFNBQ3JDQSxRQUFRLEdBQUdTLHFCQUFxQixTQUFTLEdBQUdDLFdBRTdDM0IsS0FBSyxTQUFVaEIsVUFDaEJhLFlBQVl6QixlQUFlWSxTQUFTWCxPQUFRVyxTQUFTUCxNQUFNdUIsS0FBSyxXQUM5REYsYUFDQyxTQUFVWixPQUNYMEMsUUFBUTFDLE1BQU1BLFlBS3BCWSxjQUdEUCxXQUFXLG1CQUFvQixTQUFVQyxPQUFRRSxVQUFXRyxZQUFhZ0IsUUFDeEVyQixPQUFPVSxLQUFPLFNBQVVDLEtBQ3RCLE1BQU90QixRQUFPcUIsS0FBS0ksV0FBV0gsTUFHaENYLE9BQU9xQixPQUFTQSxTQUNkZ0IsUUFBUSxFQUNSQyxRQUFRLEVBQ1JDLFFBQVMsR0FDVEMsTUFBTyxJQUdUeEMsT0FBT3lDLE9BQVMsV0FDZHZDLFVBQVV1QyxVQUVaekMsT0FBQUEsVUFBZ0IsV0FDZEUsVUFBVXdDLE1BQ1I3RCxPQUFRLGVBQ1JJLEtBQU1lLE9BQU9xQixVQUdqQnJCLE9BQU8yQyxHQUFLLFdBQ1Z6QyxVQUFVd0MsTUFDUjdELE9BQVEsYUFDUkksS0FBTWUsT0FBT3FCIiwiZmlsZSI6InNjcmlwdHMvcG9wdXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCc7XG5cbi8vIHJlbWluZGVyIGFwcFxuXG5hbmd1bGFyLm1vZHVsZSgnYXBwJywgWyduZ01hdGVyaWFsJywgJ25nTWVzc2FnZXMnLCAnYW5ndWxhck1vbWVudCddKS5jb25maWcoZnVuY3Rpb24gKCRtZFRoZW1pbmdQcm92aWRlciwgJG1kSWNvblByb3ZpZGVyKSB7XG4gIC8vIHNldCB0aGVtZVxuICAkbWRUaGVtaW5nUHJvdmlkZXIudGhlbWUoJ2RlZmF1bHQnKS5wcmltYXJ5UGFsZXR0ZSgndGVhbCcpLmFjY2VudFBhbGV0dGUoJ2RlZXAtb3JhbmdlJyk7XG4gIC8vIGljb25zXG4gICRtZEljb25Qcm92aWRlci5pY29uKCdhbGFybScsICcuLi9pbWFnZXMvaWNvbnMvaWNfYWxhcm1fd2hpdGVfMThweC5zdmcnLCAxOCkuaWNvbignYWxhcm1fYWRkJywgJy4uL2ltYWdlcy9pY29ucy9pY19hZGRfYWxhcm1fd2hpdGVfMThweC5zdmcnLCAxOCkuaWNvbigncmVwZWF0JywgJy4uL2ltYWdlcy9pY29ucy9pY19yZXBlYXRfYmxhY2tfMThweC5zdmcnLCAxOCkuaWNvbignY2xvc2UnLCAnLi4vaW1hZ2VzL2ljb25zL2ljX2Nsb3NlX3doaXRlXzE4cHguc3ZnJywgMTgpO1xufSkuc2VydmljZSgncmVtaW5kZXJTdnInLCBmdW5jdGlvbiAoJHEpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBzZWxmLmNhbGxCYWNrZ3JvdW5kID0gZnVuY3Rpb24gKG1ldGhvZCkge1xuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gQXJyYXkoX2xlbiA+IDEgPyBfbGVuIC0gMSA6IDApLCBfa2V5ID0gMTsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5IC0gMV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgdmFyIGQgPSAkcVsnZGVmZXInXSgpO1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgYXJnczogYXJnc1xuICAgIH0sIGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgaWYgKHJlc3BvbnNlLmVycm9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZC5yZWplY3QocmVzcG9uc2UuZXJyb3IpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZC5yZXNvbHZlKHJlc3BvbnNlLnJlc3VsdCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGQucHJvbWlzZTtcbiAgfTtcbn0pXG4vLyBNYWluIGNvbnRyb2xsZXJcbi5jb250cm9sbGVyKCdtYWluQ29udHJvbGxlcicsIGZ1bmN0aW9uICgkc2NvcGUsICRyb290U2NvcGUsICRtZERpYWxvZywgJG1kVG9hc3QsICRsb2csIHJlbWluZGVyU3ZyKSB7XG4gICRzY29wZS5pMThuID0gZnVuY3Rpb24gKGtleSkge1xuICAgIGZvciAodmFyIF9sZW4yID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IEFycmF5KF9sZW4yID4gMSA/IF9sZW4yIC0gMSA6IDApLCBfa2V5MiA9IDE7IF9rZXkyIDwgX2xlbjI7IF9rZXkyKyspIHtcbiAgICAgIGFyZ3NbX2tleTIgLSAxXSA9IGFyZ3VtZW50c1tfa2V5Ml07XG4gICAgfVxuXG4gICAgcmV0dXJuIGNocm9tZS5pMThuLmdldE1lc3NhZ2Uoa2V5LCBhcmdzKTtcbiAgfTtcblxuICBmdW5jdGlvbiBmZXRjaERhdGEoKSB7XG4gICAgJGxvZy5pbmZvKCdmZXRjaGluZyBkYXRhLi4uJyk7XG4gICAgcmVtaW5kZXJTdnIuY2FsbEJhY2tncm91bmQoJ3N5bmNBbGxSZW1pbmRzJywgW10pLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgJHNjb3BlLnJlbWluZHMgPSByZXN1bHQucmVtaW5kcyB8fCBbXTtcbiAgICB9KTtcbiAgfVxuXG4gICRzY29wZS5lbmFibGVDaGFuZ2VkID0gZnVuY3Rpb24gKHIpIHtcbiAgICByZW1pbmRlclN2ci5jYWxsQmFja2dyb3VuZCgnc2F2ZVJlbWluZCcsIHIpLnRoZW4oZnVuY3Rpb24gKG5yKSB7XG4gICAgICByLndoZW4gPSBuci53aGVuO1xuICAgIH0pO1xuICB9O1xuXG4gICRyb290U2NvcGUuZWRpdFJlbWluZCA9IGZ1bmN0aW9uICgkZXZlbnQpIHtcbiAgICB2YXIgcmVtaW5kID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1sxXTtcblxuICAgICRtZERpYWxvZy5zaG93KHtcbiAgICAgIGNvbnRyb2xsZXI6ICdkaWFsb2dDb250cm9sbGVyJyxcbiAgICAgIHRlbXBsYXRlVXJsOiAncmVtaW5kLnRtcGwuaHRtbCcsXG4gICAgICBwYXJlbnQ6IGFuZ3VsYXIuZWxlbWVudChkb2N1bWVudC5ib2R5KSxcbiAgICAgIHRhcmdldEV2ZW50OiAkZXZlbnQsXG4gICAgICBjbGlja091dHNpZGVUb0Nsb3NlOiB0cnVlLFxuICAgICAgbG9jYWxzOiB7IHJlbWluZDogYW5ndWxhci5jb3B5KHJlbWluZCkgfSxcbiAgICAgIG9uQ29tcGxldGU6IGZ1bmN0aW9uIG9uQ29tcGxldGUoc2NvcGUsIGVsZW1lbnQpIHtcbiAgICAgICAgZWxlbWVudFswXS5nZXRFbGVtZW50c0J5VGFnTmFtZSgnaW5wdXQnKVswXS5mb2N1cygpO1xuICAgICAgfVxuICAgIH0pLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICByZW1pbmRlclN2ci5jYWxsQmFja2dyb3VuZChyZXNwb25zZS5tZXRob2QsIHJlc3BvbnNlLmFyZ3MpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICBmZXRjaERhdGEoKTtcbiAgICAgIH0sIGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9O1xuICAvL1xuICBmZXRjaERhdGEoKTtcbn0pXG4vLyBEaWFsb2cgY29udHJvbGxlclxuLmNvbnRyb2xsZXIoJ2RpYWxvZ0NvbnRyb2xsZXInLCBmdW5jdGlvbiAoJHNjb3BlLCAkbWREaWFsb2csIHJlbWluZGVyU3ZyLCByZW1pbmQpIHtcbiAgJHNjb3BlLmkxOG4gPSBmdW5jdGlvbiAoa2V5KSB7XG4gICAgcmV0dXJuIGNocm9tZS5pMThuLmdldE1lc3NhZ2Uoa2V5KTtcbiAgfTtcblxuICAkc2NvcGUucmVtaW5kID0gcmVtaW5kIHx8IHtcbiAgICBlbmFibGU6IHRydWUsXG4gICAgcmVwZWF0OiBmYWxzZSxcbiAgICBtZXNzYWdlOiAnJyxcbiAgICBhZnRlcjogMTBcbiAgfTtcbiAgLy8gaGFuZGxlc1xuICAkc2NvcGUuY2FuY2VsID0gZnVuY3Rpb24gKCkge1xuICAgICRtZERpYWxvZy5jYW5jZWwoKTtcbiAgfTtcbiAgJHNjb3BlLmRlbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAkbWREaWFsb2cuaGlkZSh7XG4gICAgICBtZXRob2Q6ICdkZWxldGVSZW1pbmQnLFxuICAgICAgYXJnczogJHNjb3BlLnJlbWluZFxuICAgIH0pO1xuICB9O1xuICAkc2NvcGUub2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgJG1kRGlhbG9nLmhpZGUoe1xuICAgICAgbWV0aG9kOiAnc2F2ZVJlbWluZCcsXG4gICAgICBhcmdzOiAkc2NvcGUucmVtaW5kXG4gICAgfSk7XG4gIH07XG59KTsiXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=
