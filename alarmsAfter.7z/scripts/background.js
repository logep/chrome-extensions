"use strict";
var defaultData = {reminds: [], time: Date.now()}, appData = {time: -1, reminds: []}, app = {
    fixData: function () {
        var now = Date.now();
        appData.reminds.forEach(function (x) {
            if (x.when <= now) if (x.repeat && x.enable) {
                for (; x.when < now;) x.when += 6e4 * parseInt(x.after);
                chrome.alarms.create(x.name, {when: x.when})
            } else x.enable = !1, chrome.alarms.clear(x.name); else x.when > now && x.enable && chrome.alarms.get(x.name, function (alarm) {
                null === alarm && chrome.alarms.create(x.name, {when: x.when})
            })
        })
    }, syncAllReminds: function () {
        return new Promise(function (resolve) {
            chrome.storage.sync.get(defaultData, function (data) {
                data.time > appData.time ? (appData = {
                    reminds: data.reminds,
                    time: data.time
                }, app.fixData()) : appData.time > data.time && chrome.storage.sync.set(appData), resolve(appData)
            })
        })
    }, updateRemind: function (r) {
        r.enable ? (r.when = Date.now() + 6e4 * parseInt(r.after), chrome.alarms.create(r.name, {when: r.when})) : chrome.alarms.clear(r.name)
    }, deleteRemind: function (r) {
        var index = appData.reminds.findIndex(function (x) {
            return x.name === r.name
        });
        index > -1 && (this.updateRemind(r), appData.reminds.splice(index, 1), appData.time = Date.now(), this.syncAllReminds())
    }, addRemind: function (r) {
        r.name = this.randString(6), appData.reminds.push(r), appData.time = Date.now(), this.updateRemind(r), this.syncAllReminds()
    }, randString: function (x) {
        for (var s = ""; s.length < x && x > 0;) {
            var r = Math.random();
            s += .1 > r ? Math.floor(100 * r) : String.fromCharCode(Math.floor(26 * r) + (r > .5 ? 97 : 65))
        }
        return s
    }, saveRemind: function (r) {
        if (!this.validRemind(r)) return {error: "invalid data."};
        if (void 0 === r.name) return this.addRemind(r), r;
        var index = appData.reminds.findIndex(function (x) {
            return x.name === r.name
        });
        return index > -1 && (appData.reminds.splice(index, 1, r), appData.time = Date.now(), this.updateRemind(r), this.syncAllReminds()), r
    }, validRemind: function (r) {
        return void 0 === r.message || null === r.message || "" === r.message ? !1 : void 0 === r.after || null === r.after || 0 === parseInt(r.after) ? !1 : !0
    }
};
chrome.runtime.onInstalled.addListener(function (details) {
    console.log("previousVersion", details.previousVersion)
}), chrome.alarms.onAlarm.addListener(function (alarm) {
    var index = appData.reminds.findIndex(function (x) {
        return x.name === alarm.name
    });
    if (index > -1) {
        var remind = appData.reminds[index];
        remind.repeat ? app.updateRemind(remind) : remind.enable = !1, chrome.notifications.create(remind.name, {
            title: chrome.i18n.getMessage("reminderTitle"),
            type: "basic",
            message: remind.message,
            iconUrl: "images/icon-24.png"
        }), appData.time = Date.now(), app.syncAllReminds()
    }
}), chrome.notifications.onClicked.addListener(function (id) {
    chrome.notifications.clear(id)
}), chrome.runtime.onMessage.addListener(function (request, sender, callback) {
    var method = app[request.method];
    if ("function" != typeof method) return void console.error("error method");
    var p = Promise.resolve().then(function () {
        return method.apply(app, request.args)
    });
    return p.then(function (result) {
        callback(void 0 !== result && void 0 !== result.error ? {error: result.error} : {result: result})
    }), !0
}), app.syncAllReminds();
//# sourceMappingURL=background.js.map
