11. http://localhost:8085/m.api?\_gp=admin.anyattr&\_mt=getList&id=1&type=2
    11..1 http://localhost:8085/m.api?\_gp=admin.anyattr&\_mt=updateObj&anyAttrDTO={"id":1,"attr1":"66666666","attr2":"555555"} post 请求方式
    11..2 http://localhost:8085/m.api?\_gp=admin.anyattr&\_mt=insertObj&anyAttrDTO={"id":1,"attr1":"66666666","attr2":"555555"}
    11..3 http://localhost:8085/m.api?\_gp=admin.anyattr&\_mt=delById&aid=5f89f82f-d695-4fde-a167-6f73c6cb1a18
    11..4 http://localhost:8085/m.api?\_gp=admin&\_mt=login&username=guest&password=123456&verifyCode=666666 post 请求方式

###

attr16 ='app_token'

fetch('https://9ping.cn/m.api?_gp=admin.anyattr', {
method: 'POST',
mode: 'cors',
headers: {
'Content-Type': 'application/json'
},
body: JSON.stringify({
\_mt:"updateObj",
anyAttrDTO:{"id":1,"attr1":"66666666","attr2":"555555"}
}),
credentials: 'include'
})
