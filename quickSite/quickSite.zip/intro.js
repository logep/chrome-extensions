
$(function(){

getList()


// 


$('.flexBtnCancel').on('click', function(e){

	$(".popupDialog").addClass('hidden');

	})

$('.flexBtn').on('click', function(e){

	submit()

	})

  $('#feedback').on('click', function(e){
// getList()
$(".popupDialog").removeClass('hidden')
// $(".popupDialog").addClass('display', 'block');
    // window.close()
		// gp=admin.anyattr&\_mt=getList&id=1&type=2
		// 鼠标失焦 popup 直接隐藏
	// let param=JSON.stringify({"id":1,"attr1":"66666666","attr2":"555555"})
})
})


function submit(){


 // let param=JSON.stringify({"attr15":"8abfdf40-3765-4cce-be68-3e19370023ac","attr16":"app_token","attr2":$("#popupName").val(),"attr3":$("#popupDesc").val(),"attr4":$("#popupLink").val()})
  let param=JSON.stringify({"type":9,"attr2":$("#popupName").val(),"attr16":"app_token","attr3":$("#popupDesc").val(),"attr4":$("#popupLink").val()})


let url='https://9ping.cn/m.api'
//let url='http://localhost:8085/m.api'
		 $.ajax({
	url:url,
 // data:'_gp=admin.anyattr&_mt=updateObj&anyAttrDTO='+param,
  data:'_gp=admin.anyattr&_mt=insertObj&anyAttrDTO='+param,
	type:"POST",
	headers: { 
		'Content-Type': 'application/x-www-form-urlencoded'  //multipart/form-data;boundary=--xxxxxxx   application/json
},  

	cache:"false",
	dataType:"json",
	success:function(res){
		getList()
		$(".popupDialog").addClass('hidden');
	},
	error:function(data){
		console.log(data);
	}
});
}


function getList(){
		let param=9
	 let url='https://9ping.cn/m.api'
	//let url='http://localhost:8085/m.api'
			 $.ajax({
	  url:url,
	data:'_gp=admin.anyattr&_mt=getList&attr16=app_token&type='+param,
	  type:"GET",
		headers: { 
			'Content-Type': 'application/x-www-form-urlencoded'  //multipart/form-data;boundary=--xxxxxxx   application/json
	},  

	  cache:"false",
	  dataType:"json",
	  success:function(res){
			let rs=res.data
			let str=''
			for(let i=0;i<rs.length;i++){

			    // 
				str +=`
				<li>
                    <div class="card calculateSiteBook">
                  <img src="static/resource.a72b8f8.png"> 
                        <h3 title="${rs[i].attr2}">${rs[i].attr2}</h3>
                        <p title="${rs[i].attr2}">${rs[i].attr3}</p>
                        <a href="${rs[i].attr4}" class="assetId">查看详情</a>
                         
                    </div>
                </li>
				`
			}
			$('#cardDepartSite').html(str)

			
  $('.assetId').on('click', function(e){
		e.preventDefault()
		 chrome.tabs.create({url:e.currentTarget.href})
		 // window.close()
		 // gp=admin.anyattr&\_mt=getList&id=1&type=2
		 // 鼠标失焦 popup 直接隐藏
	 // let param=JSON.stringify({"id":1,"attr1":"66666666","attr2":"555555"})
 })
	  },
	  error:function(data){
	    console.log(data);
	  }
	});
}